from django.contrib import admin
from .models import Project, Phase, Block, PropertyType, PaymentPlanType,Area,Street  

# Register your models here.

class ProjectAdmin(admin.ModelAdmin):
    list_display = [
        'name',
        'shortname'
    ]

class PhaseAdmin(admin.ModelAdmin):
    list_display = [
        'name',
        'shortname'
    ]

class BlockAdmin(admin.ModelAdmin):
    list_display = [
        'name',
        'shortname'
    ]


class PropertyTypesAdmin(admin.ModelAdmin):
    list_display = [
        'name',
        'shortname'
    ]


class AreaAdmin(admin.ModelAdmin):
    list_display = ['area_sqft']

admin.site.register(Project,ProjectAdmin)
admin.site.register(Phase, PhaseAdmin)
admin.site.register(Block, BlockAdmin)
admin.site.register(PropertyType, PropertyTypesAdmin)
admin.site.register(PaymentPlanType)
admin.site.register(Area, AreaAdmin)
admin.site.register(Street)
