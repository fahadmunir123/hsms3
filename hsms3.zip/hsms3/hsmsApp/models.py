from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Project(models.Model):
    name = models.CharField(max_length=100,  unique=True)
    shortname = models.CharField(max_length=6)
    createdAt = models.DateTimeField(auto_now_add=True)
    id = models.AutoField(primary_key=True,editable=False)

    def __str__(self):
        return self.name

class Phase(models.Model):
    name = models.CharField(max_length=100 ,  unique=True)
    shortname = models.CharField(max_length=6)
    createdAt = models.DateTimeField(auto_now_add=True)
    id = models.AutoField(primary_key=True,editable=False)

    def __str__(self):
        return self.name

class Block(models.Model):
    name = models.CharField(max_length=100, unique=True)
    shortname = models.CharField(max_length=6)
    createdAt = models.DateTimeField(auto_now_add=True)
    id = models.AutoField(primary_key=True,editable=False)

    def __str__(self):
        return self.name


class PropertyType(models.Model):
    name = models.CharField(max_length=100, unique=True)
    shortname = models.CharField(max_length=6)
    createdAt = models.DateTimeField(auto_now_add=True)
    id = models.AutoField(primary_key=True,editable=False)

    def __str__(self):
        return self.name

class PaymentPlanType(models.Model):
    name = models.CharField(max_length=100, unique=True)
    # shortname = models.CharField(max_length=6)
    createdAt = models.DateTimeField(auto_now_add=True)
    id = models.AutoField(primary_key=True,editable=False)

    def __str__(self):
        return self.name

class Area(models.Model):
    area_sqft = models.CharField(max_length=100, unique=True)
    # shortname = models.CharField(max_length=6)
    createdAt = models.DateTimeField(auto_now_add=True)
    id = models.AutoField(primary_key=True,editable=False)

    def __str__(self):
        return self.area_sqft

class Street(models.Model):
    name = models.CharField(max_length=100, unique=True)
    # shortname = models.CharField(max_length=6)
    createdAt = models.DateTimeField(auto_now_add=True)
    id = models.AutoField(primary_key=True,editable=False)

    def __str__(self):
        return self.name


# HOW 






    
