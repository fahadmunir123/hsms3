from django.apps import AppConfig


class HsmsappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hsmsApp'
    verbose_name = "Settings Society"
