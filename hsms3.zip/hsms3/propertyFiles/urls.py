from django.urls import path
from . import views


urlpatterns = [
    path('customer/<str:id>', views.customer)
]