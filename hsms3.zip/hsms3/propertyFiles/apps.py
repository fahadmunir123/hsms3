from django.apps import AppConfig


class PropertyfilesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'propertyFiles'
    verbose_name = "Property Files"
