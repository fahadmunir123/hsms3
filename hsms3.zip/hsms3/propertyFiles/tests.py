from django.test import TestCase

from .models import PaymentPlan, PaymentPlanLine,PaymentPlanType
