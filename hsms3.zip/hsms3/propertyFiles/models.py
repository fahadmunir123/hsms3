from hsmsApp.models import Project, Phase, Block, PropertyType, Street, Area,PaymentPlanType
from accounting.models import AccountHead, People
from django.core.exceptions import ValidationError
from django.db import models
from django.contrib.auth.models import User


# Create your models here.

class LandPurchase(models.Model):
    date = models.DateField()
    project = models.ForeignKey(Project, on_delete=models.RESTRICT , null=False)
    phase = models.ForeignKey(Phase, on_delete=models.RESTRICT , null=False)
    landInformation = models.TextField(null=True, blank=True, max_length=500)
    image= models.ImageField(null=True, blank=True)
    cost=models.DecimalField(max_digits=10, decimal_places=2)
    accounthead=models.ForeignKey(AccountHead, on_delete=models.RESTRICT, null=False)
    
    
    createdAt = models.DateTimeField(auto_now_add=True)
    id = models.AutoField(primary_key=True,editable=False)

    def __str__(self):
        return str(self.date)

class FileDetail(models.Model):
    # date = models.DateField()
    Choice = (
    
    ("PHATA", "PHATA"),
    ("NAPHDA", "NAPHDA"),
    ("BANK", "BANK"),
    ("SELF-FINANCE","SELF-FINANCE")
    
)
    project = models.ForeignKey(Project, on_delete=models.RESTRICT , null=False)
    phase = models.ForeignKey(Phase, on_delete=models.RESTRICT , null=False)
    block = models.ForeignKey(Block, on_delete=models.RESTRICT , null=False)
    street = models.ForeignKey(Street, on_delete=models.RESTRICT , null=False)
    area_sqft = models.ForeignKey(Area, on_delete=models.RESTRICT , null=False)
    propertyType = models.ForeignKey(PropertyType, on_delete=models.RESTRICT , null=False)
    fileNumber = models.CharField( max_length=20, unique=True)
    flatNumber = models.CharField(null=True, blank=True, max_length=20)
    barcode=models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)
    aquiringMethod=models.CharField( max_length=100, choices=Choice, null=True, blank=True )

    cash_price=models.DecimalField(max_digits=15, decimal_places=2)
    cost_price=models.DecimalField(max_digits=15, decimal_places=2)
    installment_price=models.DecimalField(max_digits=15, decimal_places=2)
    attachment= models.ImageField(null=True, blank=True)
    # accounthead=models.ForeignKey(AccountHead, on_delete=models.RESTRICT, null=False)
    
    
    createdAt = models.DateTimeField(auto_now_add=True)
    id = models.AutoField(primary_key=True,editable=False)

    def __str__(self):
        return str(self.fileNumber)


class DealerBooking(models.Model):
    date = models.DateField()
    people = models.ForeignKey(People, on_delete=models.RESTRICT , limit_choices_to={'people': 'Dealer'}, null=False)
    dealerAmountReceivedDescription = models.TextField(null=True, blank=True, max_length=500)
    amount=models.DecimalField(max_digits=10, decimal_places=2)
    image= models.ImageField(null=True, blank=True)
    accounthead=models.ForeignKey(AccountHead, on_delete=models.RESTRICT, null=False)
    fileNumber = models.ManyToManyField(FileDetail, null=False)

    createdAt = models.DateTimeField(auto_now_add=True)
    id = models.AutoField(primary_key=True,editable=False)

    def __str__(self):
        return str(self.date)







class CustomerBooking(models.Model):
    date = models.DateField()
    customer_name = models.ForeignKey(People, on_delete=models.RESTRICT , limit_choices_to={'people': 'Customer'}, null=False )
  
    fileNumber = models.ForeignKey(FileDetail, on_delete=models.RESTRICT, null=False, unique=True)

    createdAt = models.DateTimeField(auto_now_add=True)
    id = models.AutoField(primary_key=True,editable=False)

    def __str__(self):
        return str(self.date)

    def clean(self):
        if CustomerBooking.objects.filter(fileNumber=self.fileNumber).exclude(id=self.id).exists():
            raise ValidationError(f"File {self.fileNumber} Already Booked by A Customer")


class PaymentPlan(models.Model):
    fileNumber = models.ForeignKey(FileDetail, on_delete=models.RESTRICT, null=False, unique=True)

    createdAt = models.DateTimeField(auto_now_add=True)
    id = models.AutoField(primary_key=True,editable=False)

    def __str__(self):
        return str(self.fileNumber)
            

class PaymentPlanLine(models.Model):

    payment_plan = models.ForeignKey(PaymentPlan, on_delete=models.CASCADE)
    plan_Type = models.ForeignKey(PaymentPlanType, on_delete=models.RESTRICT, null=False)
    amount=models.DecimalField(max_digits=10, decimal_places=2)
    number_of_Payments=models.IntegerField(default =1)
    start_date = models.DateField()
    
    payment_Intervals=models.IntegerField(default =1)
    due_In_Days=models.IntegerField(default =5)
