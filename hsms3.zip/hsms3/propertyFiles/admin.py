from django.contrib import admin
from .models import LandPurchase, FileDetail, DealerBooking, CustomerBooking, PaymentPlan,PaymentPlanLine
from django import forms
from django.core.exceptions import ValidationError

# Register your models here.


class LandPurchaseAdmin(admin.ModelAdmin):
    list_display = [
        'date',
        'project',
        'phase',
        'landInformation',
        'image',
        'accounthead',
        'createdAt',
        'id',
    ]

class FileddetailAdmin(admin.ModelAdmin):
    list_display = [
        
        'project',
        'phase',
        'block',
        'street',
        'area_sqft',
        'propertyType',
        'fileNumber',
        'flatNumber',
        'barcode',
        'aquiringMethod', 
        'cash_price',
        'cost_price',
        'installment_price',
        
        'attachment',
        
        'createdAt',
        'id',
    ]


class DealerBookingAdmin(admin.ModelAdmin):
    list_display =[
        'date',
        'people',
        'dealerAmountReceivedDescription',
        'amount',
        'image',
        'accounthead',
        'createdAt',
        'id',
    ]

class CustomerBookingAdmin(admin.ModelAdmin):
    list_display= [
        'date',
        'customer_name',
        'createdAt',
        'fileNumber',
        'id',
    ]

class PaymentPlanLineFormSet(forms.models.BaseInlineFormSet):
    def clean(self):
        super().clean()
        count = 0
        for form in self.forms:
            if not hasattr(form, 'cleaned_data') or not form.cleaned_data:
                continue
            else:
                count += 1

        if count == 0:
            raise ValidationError('Please Define Payment plan lines')
        return self.cleaned_data

class PaymentPlanLineInline(admin.TabularInline):
    model = PaymentPlanLine
    formset = PaymentPlanLineFormSet
    extra = 0


class PaymentPlanAdmin(admin.ModelAdmin):
    inlines = [PaymentPlanLineInline, ]
    list_display=[
        'fileNumber',
        
    ]


admin.site.register(LandPurchase, LandPurchaseAdmin)
admin.site.register(FileDetail, FileddetailAdmin)
admin.site.register(DealerBooking, DealerBookingAdmin)
admin.site.register(CustomerBooking, CustomerBookingAdmin)
admin.site.register(PaymentPlan,PaymentPlanAdmin)
