from datetime import timedelta

from django.shortcuts import render

from .models import (CustomerBooking, FileDetail, PaymentPlan, PaymentPlanLine,
                     PaymentPlanType, People )
# from ..enteriesAccounts.models import InstallmentReceipt


def customer(request, id):
    customers = People.objects.get(id=id)
    customer_booking = customers.customerbooking_set.first()
    file_detail = customer_booking.fileNumber
    payment_plan = PaymentPlan.objects.get(fileNumber=file_detail)
    # installmentRec= file_detail.

    payments_data = []
    
    for payment_plan_line in payment_plan.paymentplanline_set.all():
        for i in range(payment_plan_line.number_of_Payments):
            payments_data.append({
                'date': payment_plan_line.start_date + timedelta(days=payment_plan_line.payment_Intervals * i),
                'type': payment_plan_line.plan_Type.name,
                'payable_amount': payment_plan_line.amount,
            })
    payments_data.sort(key = lambda x:x['date'])

    sum_payable_amount = 0
    for p in payments_data:
        sum_payable_amount += p['payable_amount']

    context = {
        'customers': customers,
        'file_detail': file_detail,
        'customer_booking': customer_booking,
        'payments_data': payments_data,
        'sum_payable_amount': sum_payable_amount
    }
    return render(request, 'accounts/dashboard.html', context)
