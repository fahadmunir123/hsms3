from django.contrib import admin
from .models import AccountHead, People

# Register your models here.


class AccountHeadAdmin(admin.ModelAdmin):
    list_display = [
        'accounthead',
        'typeofhead',
        'createdAt',
        'id',
    ]

class PeopleAdmin(admin.ModelAdmin):
    list_display = [
        'people',
        'name',
        'businessName',
        'fatherName',
        'husbandName',
        'cnic',
        'phone',
        'address',
        'image',
        'kinname',
        'kinfatherName',
        'kincnic',
        'kinphone',
        'kinaddress',
        'id',
    ]


admin.site.register(People, PeopleAdmin)
admin.site.register(AccountHead, AccountHeadAdmin)