# from hsmsApp.models import Project, Phase
from django.db import models
# from django.contrib.auth.models import User


# Create your models here.

class AccountHead(models.Model):
    accounthead = models.CharField(max_length=100, unique=True)

    # date = models.DateField()
    # project = models.ForeignKey(Project, on_delete=models.RESTRICT , null=False)
    # phase = models.ForeignKey(Phase, on_delete=models.RESTRICT , null=False)
    # landInformation = models.TextField(null=True, blank=True, max_length=500)
    # image= models.ImageField(null=True, blank=True)
    # cost=models.DecimalField(max_digits=10, decimal_places=2)
    
    COA_CHOICES = (
    ("Sales / Service Income", "Sales / Service Income"),
    ("Cash / Bank", "Cash / Bank"),
    ("Non-current Liabilities", "Non-current Liabilities"),
    ("Current Liabilities", "Current Liabilities"),
    ("Other Income", "Other Income"),                    
    ("Inventory", "Inventory"),
    ("Finished Goods" , "Finished Goods"),
    ("Cost Direct", "Cost Direct"),
    ("Cost Indirect" , "Cost Indirect"),
    ("Administrative Expenses","Administrative Expenses"),
    ("Selling Expenses", "Selling Expenses"),
    ("Financial Expenses", "Financial Expenses" ),
    ("Tax Expense", "Tax Expense"),
    ("Non-Current Asset", "Non-Current Asset"),
    ("Current Asset", "Current Asset"),
    ("Recieveable / Payable", "Recieveable / Payable"),
    ('Equity Capital' , 'Equity Capital' ),
    ("Equity Reserves", "Equity Reserves"),
)

    typeofhead = models.CharField( max_length=100, choices=COA_CHOICES, )
    createdAt = models.DateTimeField(auto_now_add=True)
    id = models.AutoField(primary_key=True,editable=False)

    def __str__(self):
        return str(f'{self.accounthead} - [{self.typeofhead}]')
    
   


class People(models.Model):
    # people = models.CharField(max_length=60)

    COA_PEOPLE = (
    ("Customer", "Customer"),
    ("Dealer", "Dealer"),
    ("Employee", "Employee"),
    ("Supplier", "Supplier"), 
)
    people = models.CharField( max_length=100, choices=COA_PEOPLE, )
    name = models.CharField(max_length=60, unique=True)
    businessName=models.CharField(max_length=60, null=True, blank=True)
    fatherName=models.CharField(max_length=60, null=True, blank=True)
    # fatherName=models.CharField(max_length=60, null=True, blank=True)
    husbandName=models.CharField(max_length=60, null=True, blank=True)
    cnic=models.CharField(max_length=13, unique=True)
    phone=models.CharField(max_length=7)
    address=models.CharField(max_length=100, null=True, blank=True)
    image= models.ImageField(null=True, blank=True)


    kinname = models.CharField(max_length=60)
 
    kinfatherName=models.CharField(max_length=60, null=True, blank=True)
    kincnic=models.CharField(max_length=13)
    kinphone=models.CharField(max_length=7)
    kinaddress=models.CharField(max_length=100, null=True, blank=True)
    createdAt = models.DateTimeField(auto_now_add=True)
    id = models.AutoField(primary_key=True,editable=False)

    def __str__(self):
        return str(f'{self.name} - [{self.people}]')