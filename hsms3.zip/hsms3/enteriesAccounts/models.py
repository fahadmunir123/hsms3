from django.db import models
from hsmsApp.models import Project, Phase, Block, PropertyType, Street, Area,PaymentPlanType
from accounting.models import AccountHead, People
from propertyFiles.models import FileDetail


class InstallmentReceipt(models.Model):
    date = models.DateField()
    file_Number=models.ForeignKey(FileDetail, on_delete=models.RESTRICT, null=False )
    payment_description = models.TextField(null=True, blank=True, max_length=500)
    receipt_No=models.CharField(max_length=10 )
    fine=models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True,)
    amount_Receiving_Ac=models.ForeignKey(AccountHead, on_delete=models.RESTRICT, limit_choices_to={'typeofhead': 'Cash / Bank'}, null=False)
    attachment= models.ImageField(null=True, blank=True)
    
    createdAt = models.DateTimeField(auto_now_add=True)
    id = models.AutoField(primary_key=True,editable=False)
        

    def __str__(self):
        return str(self.date)

class InstallmentReceiptLines(models.Model):
    installment_receipt = models.ForeignKey(InstallmentReceipt, on_delete=models.CASCADE)
    amount=models.DecimalField(max_digits=10, decimal_places=2, null=False)
    payment_type =models.ForeignKey(PaymentPlanType, on_delete=models.RESTRICT, null=False)



# class JournalVoucher(models.Model):
#     date = models.DateField()
#     file_Number=models.ForeignKey(FileDetail, on_delete=models.RESTRICT, null=False )
#     payment_description = models.TextField(null=True, blank=True, max_length=500)
#     receipt_No=models.CharField(max_length=10 )
#     fine=models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True,)
#     accounthead=models.ForeignKey(AccountHead, on_delete=models.RESTRICT, null=False)
#     amount=models.DecimalField(max_digits=10, decimal_places=2)
#     attachment= models.ImageField(null=True, blank=True)
    
    
#     createdAt = models.DateTimeField(auto_now_add=True)
#     id = models.AutoField(primary_key=True,editable=False)

#     def __str__(self):
#         return str(self.date)