from django.contrib import admin
from .models import InstallmentReceipt, InstallmentReceiptLines
from django import forms
from django.core.exceptions import ValidationError

# Register your models here.


class PaymentPlanLineFormSet(forms.models.BaseInlineFormSet):
    def clean(self):
        super().clean()
        count = 0
        for form in self.forms:
            if not hasattr(form, 'cleaned_data') or not form.cleaned_data:
                continue
            else:
                count += 1

        if count == 0:
            raise ValidationError('Please Define Installment Amount and its Type')
        return self.cleaned_data

class InstallmentReceiptInline(admin.TabularInline):
    model = InstallmentReceiptLines
    formset = PaymentPlanLineFormSet
    extra = 0

   

class InstallmentReceiptAdmin(admin.ModelAdmin):
    inlines = [InstallmentReceiptInline, ]
    list_display = [
        'id',
        'date',
        'file_Number',
        'receipt_No',
        'fine',
        'amount_Receiving_Ac',
        # 'amount',
        'attachment',
        # 'payment_type',
        'createdAt',
    ]
    
    # def render_change_form(self, request, context, *args, **kwargs):
    #      context['adminform'].form.fields['amount_Receiving_Ac'].queryset = InstallmentReceipt.objects.filter(amount_Receiving_Ac__iexact='cash')
    #      return super(InstallmentReceiptAdmin, self).render_change_form(request, context, *args, **kwargs)


admin.site.register(InstallmentReceipt, InstallmentReceiptAdmin)