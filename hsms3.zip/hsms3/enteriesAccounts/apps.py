from django.apps import AppConfig


class EnteriesaccountsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'enteriesAccounts'
    verbose_name = "Entries Accounts"
